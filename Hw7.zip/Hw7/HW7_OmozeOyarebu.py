"""
Omoze Oyarebu
CS 100 2023S Section 012
HW 06, March 30, 2023

"""

#Problem 1
def file_copy(in_file,out_file):
    filename = open(in_file, "r")
    print("Problem1.txt contains:")
    print(filename.read(),"\n")

    filename.seek(0) #reset file pointer to the beginning of the file

    #create a second file
    filename2 = open(out_file, "w")
    
    #filename2.write(filename.read())
    
    #reading each line in filename and writing to filename2
    for line in filename.readline():
        filename2.write(line)
    
    

    filename2 = open(out_file, "r")
    print("copyProblem1.txt contains:")
    print(filename2.read())
    
    #close both files
    filename.close()
    filename2.close()

file_copy("Problem1.txt","copyProblem1.txt")

#Problem 2
def file_stats(in_file):
     try:
        file = open(in_file, "r")
        count_lines = 0
        count_words = 0
        count_characters = 0
        for line in file:
            count_lines += 1
            words = line.split(" ") #split() creates substrings of each word present in the file
            count_words+= len(words)
            count_characters+= len(line)

        print("Number of lines:",count_lines)
        print("Number of words:",count_words)
        print("Number of characters:",count_characters)

        file.close()
     except FileNotFoundError:
        print("The file you entereed is not found")

file_stats("Problem1.txt")
print()

#Problem 3
#beta
#Note- Can't seem to figure out how to print occurrences line by line?
#     and remove any puntauation without removing a specific manually. I tried using the string and re modules but to no success
def repeat_words(in_file,out_file):
   try:
      f = open(in_file, "r")

      #create a second file
      f2 = open(out_file, "w")

      for line in f:
         wordss = line.replace("!","").lower().split(" ")
         word_list = []
         for word in wordss:
            #word = word.lower()
            if (wordss.count(word) > 1) and (word not in word_list):
               f2.write(word + "\n")
               word_list.append(word)
      
      f2 = open(out_file, "r")
      print("Repeated words are:")
      print(f2.read())

      f.close()
      f2.close()
    
   except FileNotFoundError:
      print("The file you entered is not found")


repeat_words("catInTheHat.txt","catRepWords.txt")
    