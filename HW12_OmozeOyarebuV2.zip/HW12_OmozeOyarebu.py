"""
Omoze Oyarebu
CS 100 2023S Section 012
HW 12, April 23, 2023

"""
#Problem 1
def safeOpen(filename:str):
    try:
        f = open(filename,"r")
        return f
    except FileNotFoundError:
        return None

inputFile = safeOpen('radar.txt')
print(inputFile)


#Problem 2
def safeFloat(x):
    try:
        num = float(x)
        return num
    except ValueError:
        return 0.0
    

f= safeFloat('abc')
print(f)


#problem 3
#Final Release
import re

def safeOpenV2():
    chance =0
    while (chance != 2):
        try:
            in_data = input("Enter the name of the input file you want to process")
            
            #open a file
            f = open(in_data,"r")
            
            return f
        except FileNotFoundError:
            chance += 1
            if (chance == 2):
                print("File not found. Yet another human error. Goodbye")
                break
                
            else:
                print("File not file found. Try again")
                #in_data = input("Enter the name of the input file you want to process")
                continue

def averagespeed():
           
    f = safeOpenV2()     
    
    """
    the case where safeopenv2 doesn't return an a file object to read from causing a
    typeerror from trying to look into the file in the for loop

    """
    if f is None:
        return

    #counters
    sum = 0
    n = 0

    #look into the file
    for num_line in f:

        numbers = num_line.strip().split()

        for nums in numbers:
            #match any number that contains only digits or digits with decimal points
            valid_pattern = re.match(r'^[0-9.]*$',nums)

            if (valid_pattern) and (safeFloat(nums) > 2):
                #print(valid_pattern) 
                sum += safeFloat(nums)
                n += 1

            else:
                continue
            
    average = sum/n
    #print("n-number of items used:",n)
    print("The average speed is:", "{:.2f}".format(average),"miles per hour")

    f.close()
        

averagespeed()


"""
#problem 3
#beta version
import re

def averagespped():
    chance = 0
    while (chance != 2):
        try:
            #print("Enter the name of the input file you want to process")
            in_data = input("Enter the name of the input file you want to process")
            f = open(in_data, "r")
            #print(f.read())
            
            #counters
            sum = 0
            n = 0

            #look into the file
            for num in f:

                #match any number that contains only digits or digits with decimal points
                valid_pattern = re.match(r'^[0-9.]*$',num.strip())

                if (valid_pattern):
                        sum += float(num)
                        n += 1
                else:
                    continue
            
            average = sum/n
            print("The average speed is",average,"miles per hour")
               
            break
        except FileNotFoundError:
            chance += 1
            if (chance == 2):
                print("File not found. Yet another human error. Goodbye")
                break
            else:
                print("File not file found. Try again")
                #in_data = input("Enter the name of the input file you want to process")
                continue
            
averagespped()
"""