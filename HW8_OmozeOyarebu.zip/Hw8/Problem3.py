"""
Omoze Oyarebu
CS 100 2023S Section 012
HW 08, April 14, 2023
"""

#problem 3 hw8
def sharedOneLetter(wordList:list):
    words_dictionary = dict()
    
    #fill the dictionary keys with words
    for words in wordList:
            
        words_dictionary[words] = []

    #look in the dictionary keys and list, then fill in the values
    for keys,values in words_dictionary.items():
        for words in wordList:
            for char in words:
                if (char in keys) and (words not in values):
                    words_dictionary[keys] += [words]
                 
                
        
    return words_dictionary

testlist1 = ['I', 'say', 'what', 'I', 'mean', 'and', 'I', 'mean', 'what', 'I', 'say']
testlist2 = ['Hi','my','name','is','Omoze','Oyarebu']
testlist3 = ['It\'s', 'nice', 'to', 'meet', 'you']
print(sharedOneLetter(testlist1))
print(sharedOneLetter(testlist2))
print(sharedOneLetter(testlist3))
