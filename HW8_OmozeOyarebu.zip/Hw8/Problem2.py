"""
Omoze Oyarebu
CS 100 2023S Section 012
HW 08, April 14, 2023
"""

#Problem 2
def initialLetter(wordList:list):
    Words = dict()
    for word in wordList:
        if(word[0] not in Words):
            Words[word[0]] = [word]
        else:
            continue
        
    return Words

testlist1 = ['I', 'say', 'what', 'I', 'mean', 'and', 'I', 'mean', 'what', 'I', 'say']
testlist2 = ['Hi','my','name','is','Omoze','Oyarebu']
testlist3 = ['It\'s', 'nice', 'to', 'meet', 'you']
print(initialLetter(testlist1))
print(initialLetter(testlist2))
print(initialLetter(testlist3))
