"""
Omoze Oyarebu
CS 100 2023S Section 012
HW 08, April 14, 2023
"""

#Problem 1
#approch 
#create list
#look through that list
#if a begining letter in not in the dict(), add it to a dictionary as a key and intialize the value to 1
#else update the key's value by adding a 1
#return the dictionary
def initialLetterCount(wordList:list):
    firstWordCount = dict()
    for firstword in wordList:
        if(firstword[0] not in firstWordCount):
            firstWordCount[firstword[0]] = 1
        else:
            firstWordCount[firstword[0]] += 1
    return firstWordCount

    


testList1 = ['I', 'say', 'what', 'I', 'mean', 'and', 'I', 'mean', 'what', 'I', 'say']
testList2 = ['Hi','my','name','is','Omoze','Oyarebu']
testList3 = ['It\'s', 'nice', 'to', 'meet', 'you']
print(initialLetterCount(testList1))
print(initialLetterCount(testList2))
print(initialLetterCount(testList3))

